"use client"

import  from "../assets/script"

export default function SyntheticV0PageForDeployment() {
  return < />
}