;(() => {
  const ham = document.querySelector(".hamburger")
  const nav = document.querySelector(".nav")
  if (ham && nav) {
    ham.addEventListener("click", () => nav.classList.toggle("open"))
    document.addEventListener("click", (e) => {
      if (!nav.contains(e.target) && e.target !== ham) nav.classList.remove("open")
    })
  }

  // Clock on morning page - 12 hour format only
  const clockEl = document.getElementById("clock")
  const dateEl = document.getElementById("date")
  function tick() {
    const now = new Date()
    if (clockEl)
      clockEl.textContent = now.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      })
    if (dateEl)
      dateEl.textContent = now.toLocaleDateString("en-GB", {
        weekday: "long",
        year: "numeric",
        month: "short",
        day: "numeric",
      })
  }
  tick()
  setInterval(tick, 1000)

  // Show Sunday-only content only on Sundays
  const isSunday = new Date().getDay() === 0
  document.querySelectorAll('[data-sunday-only="true"]').forEach((el) => {
    el.style.display = isSunday ? "" : "none"
  })

  // Routine checklists - now using localStorage instead of server data
  const routineLists = document.querySelectorAll(".checklist[data-routine]")
  if (routineLists.length) {
    // Default routines for HTML version
    const defaultRoutines = {
      azilanDaily: [
        { label: "Morning routine", duration: "2h" },
        { label: "Snacks", duration: "15m" },
        { label: "Playing", duration: "45m" },
        { label: "Study", duration: "2h" },
        { label: "Series", duration: "1h" },
        { label: "Eating", duration: "1h" },
      ],
      azilanSunday: [
        { label: "Warm up", duration: "15m" },
        { label: "Running", duration: "30m" },
        { label: "Yoga", duration: "45m" },
        { label: "Fresh up", duration: "15m" },
        { label: "Breakfast", duration: "20m" },
        { label: "Series", duration: "2h" },
        { label: "Playing", duration: "2h" },
        { label: "Skill training", duration: "2h" },
        { label: "Playing", duration: "1.5–2h" },
        { label: "Kabaddi", duration: "1h" },
        { label: "Snacks", duration: "1h" },
        { label: "Study", duration: "2.5h" },
        { label: "Series", duration: "1h" },
        { label: "Eating", duration: "1h" },
      ],
      amzhaSunday: [
        { label: "Wake up", duration: "1:00" },
        { label: "Tea", duration: "1:00 to 1:30" },
        { label: "Play", duration: "1:30 to 2:00" },
        { label: "Series", duration: "2:00 to 4:00" },
        { label: "Reels", duration: "4:00 to 5:50" },
        { label: "Tea", duration: "5:50 to 6:00" },
        { label: "Prayer", duration: "6:00 to 6:25" },
        { label: "Play", duration: "6:25 to 7:00" },
        { label: "Study", duration: "7:00 to 8:25" },
        { label: "Eating", duration: "8:25 to 9:00" },
        { label: "Song", duration: "9:00 to 10:00" },
        { label: "Sleeping", duration: "10:00 to 5:00" },
      ],
    }

    routineLists.forEach((ul) => {
      const key = ul.getAttribute("data-routine")
      const user = ul.getAttribute("data-user") || sessionStorage.getItem("welcomeToWeb_currentUser") || "guest"
      const items = defaultRoutines[key] || []

      // Load state from localStorage per user+date
      const today = new Date().toISOString().slice(0, 10)
      const storeKey = `routine:${user}:${key}:${today}`
      let state = {}
      try {
        state = JSON.parse(localStorage.getItem(storeKey) || "{}")
      } catch {
        state = {}
      }

      ul.innerHTML = ""
      items.forEach((it, idx) => {
        const li = document.createElement("li")
        li.className = "list"
        li.innerHTML = `
          <label style="display:flex;align-items:center;gap:.6rem;cursor:pointer">
            <input type="checkbox" ${state[idx] ? "checked" : ""} data-idx="${idx}" />
            <span>${it.label ?? ""} <span class="muted">(${it.duration ?? ""})</span></span>
          </label>
        `
        ul.appendChild(li)
      })

      ul.addEventListener("change", (e) => {
        const cb = e.target
        if (cb && cb.matches('input[type="checkbox"]')) {
          const idx = cb.getAttribute("data-idx")
          state[idx] = cb.checked
          localStorage.setItem(storeKey, JSON.stringify(state))
        }
      })
    })
  }

  // Subtle transition on navigation
  document.querySelectorAll("a[href]").forEach((a) => {
    const href = a.getAttribute("href") || ""
    if (href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("javascript:")) return
    a.addEventListener("click", (e) => {
      if (a.target === "_blank") return
      document.body.classList.add("fade-out")
    })
  })
})()

// Optional: add CSS fade-out via injected style (keeps CSS file lean)
;(() => {
  const style = document.createElement("style")
  style.textContent = `
    .fade-out { animation: fadeOut .2s ease-out both }
    @keyframes fadeOut { to { opacity: .0; transform: translateY(4px) } }
  `
  document.head.appendChild(style)
})()
